print("app.py Loaded")

def launch():
    print("hello")
